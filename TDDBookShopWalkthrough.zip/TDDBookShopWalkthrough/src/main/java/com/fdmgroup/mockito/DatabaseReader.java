package com.fdmgroup.mockito;

public interface DatabaseReader {

	public int readQuantity(String id);
	
}
