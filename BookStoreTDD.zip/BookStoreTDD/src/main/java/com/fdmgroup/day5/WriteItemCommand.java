package com.fdmgroup.day5;

import com.fdmgroup.task1.model.Book;

public interface WriteItemCommand {

	void insertItem(Book book);
}
