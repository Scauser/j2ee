package com.fdmgroup.java_week1_assessment;

import java.util.Map;

public interface DatabaseReader {

	Map<String, Trainee> readGroup();
}
