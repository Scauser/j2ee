package com.fdmgroup.java_week1_assessment;

public class Trainee {

}
