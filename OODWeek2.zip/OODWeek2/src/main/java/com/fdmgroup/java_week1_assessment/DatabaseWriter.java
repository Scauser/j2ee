package com.fdmgroup.java_week1_assessment;

public interface DatabaseWriter {

	void addTrainee(Trainee trainee);
	
	void deleteTraineeByUsername(String username);
}
